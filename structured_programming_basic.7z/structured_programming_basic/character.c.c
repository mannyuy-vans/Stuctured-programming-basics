#include <stdio.h>
int main ()
{
char c;
printf("Enter a character: ");
scanf("%c",&c);
if ((c>='A' && c<='Z')||(c>='a'&& c<='z'))
{
printf("this is a letter.\n");
if(c<='A' && c<='Z')
{
printf("Enter is a capital letter.\n");
}else{ 
printf("Enter is a small case letter.\n");
}
}
else if(c>='0'&& c <='9'){
printf("Enter is a digit.\n");
}else
{
printf("Enter it's a special symbol.\n");
}
return 0;
}