#include <stdio.h>
long long int power (int x, unsigned int y)
{
long long int result=1;
while (y>0)
{
if (y % 2==1)
result *=x;
y=y/2;
x=x*x;
}
return result ;
}
int main ()
{
int x=3;
unsigned y=3;
printf("%d raised the power of %u is %11d\n",x,y, power(x,y));
return 0;
}